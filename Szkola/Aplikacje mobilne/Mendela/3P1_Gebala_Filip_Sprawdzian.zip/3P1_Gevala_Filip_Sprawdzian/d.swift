func koduj(_ input: String, _n : Int) -> String{
    var out = ""
    
}